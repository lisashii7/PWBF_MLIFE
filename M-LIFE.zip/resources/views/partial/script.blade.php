
    <!-- Bootstrap core JavaScript-->
    <script src="{{asset('sb-admin/vendor/jquery/jquery.min.js')}}"></script>
    <script src="{{asset('sb-admin/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>

    <!-- Core plugin JavaScript-->
    <script src="{{asset('sb-admin/vendor/jquery-easing/jquery.easing.min.js')}}"></script>

    <!-- Custom scripts for all pages-->
    <script src="{{asset('sb-admin/js/sb-admin-2.min.js')}}"></script>

    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>

    <script>
        $(document).ready( function () {
    $('#table_id').DataTable();
} );
    </script>